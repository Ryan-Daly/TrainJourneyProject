document.getElementById('getByEmail').addEventListener('click', getByEmail);
document.getElementById('getByBookingRefNo').addEventListener('click', getByBookingRefNo);
document.getElementById('getByTicketRefNo').addEventListener('click', getByTicketRefNo);
document.getElementById('submit-btn').addEventListener('click', formSubmit);
// document.getElementById('submit-btn').addEventListener('click', getReservation);
// document.getElementById('addPost').addEventListener('submit', addPost);


function getByEmail(e){
    e.preventDefault();
    let email = document.getElementById('searchBar').value;
    console.log(email)


    fetch(`http://localhost:8080/search/email/${email}`)
    .then((res) => res.json())
    .then((data) => {
    console.log(data);
    let output = '<h2 class="mb-4">Booking</h2>';
    // data.forEach(function(booking){
    let booking = data;
    output = `
        <ul class="list-group mb-3">
        <li class="list-group-item">Booking Reference Number: ${booking.bookingReferenceNumber}</li>
        <li class="list-group-item">Ticket Reference Number: ${booking.ticketReferenceNumber}</li>
        <li class="list-group-item">Train ID: ${booking.trainID}</li>
        <li class="list-group-item">Departure Station: ${booking.departureStation}</li>
        <li class="list-group-item">Departure Time: ${booking.departureTime}</li>
        <li class="list-group-item">Destination Station: ${booking.destinationStation}</li>
        <li class="list-group-item">Arrival Time: ${booking.arrivalTime}</li>
        <li class="list-group-item">Fare: ${booking.fare}</li>
        </ul>
    `;
    document.getElementById('output').innerHTML = output;
    })
    .catch((err) => console.log(err))
}

function getByBookingRefNo(e){
    e.preventDefault();

    let bookingReferenceNumber = document.getElementById('searchBar').value;

    fetch(`http://localhost:8080/search/booking/${bookingReferenceNumber}`)
    .then((res) => res.json())
    .then((data) => {
    console.log(data.ticketReferenceNumber)
    let output = '<h2 class="mb-4">Booking</h2>';
    // data.forEach(function(booking){
    let booking = data;
    output = `
        <ul class="list-group mb-3">
        <li class="list-group-item">Booking Reference Number: ${booking.bookingReferenceNumber}</li>
        <li class="list-group-item">Ticket Reference Number: ${booking.ticketReferenceNumber}</li>
        <li class="list-group-item">Train ID: ${booking.trainID}</li>
        <li class="list-group-item">Departure Station: ${booking.departureStation}</li>
        <li class="list-group-item">Departure Time: ${booking.departureTime}</li>
        <li class="list-group-item">Destination Station: ${booking.destinationStation}</li>
        <li class="list-group-item">Arrival Time: ${booking.arrivalTime}</li>
        <li class="list-group-item">Fare: ${booking.fare}</li>
        </ul>
    `;
    document.getElementById('output').innerHTML = output;
    })
    .catch((err) => console.log(err))
}

function getByTicketRefNo(e){
    e.preventDefault();

    let ticketReferenceNumber = document.getElementById('searchBar').value;

    fetch(`http://localhost:8080/search/ticket/${ticketReferenceNumber}`)
    .then((res) => res.json())
    .then((data) => {
    console.log(data.ticketReferenceNumber)

    let output = '<h2 class="mb-4">Booking</h2>';
    // data.forEach(function(booking){
    let booking = data;
    output = `
        <ul class="list-group mb-3">
        <li class="list-group-item">Booking Reference Number: ${booking.bookingReferenceNumber}</li>
        <li class="list-group-item">Ticket Reference Number: ${booking.ticketReferenceNumber}</li>
        <li class="list-group-item">Train ID: ${booking.trainID}</li>
        <li class="list-group-item">Departure Station: ${booking.departureStation}</li>
        <li class="list-group-item">Departure Time: ${booking.departureTime}</li>
        <li class="list-group-item">Destination Station: ${booking.destinationStation}</li>
        <li class="list-group-item">Arrival Time: ${booking.arrivalTime}</li>
        <li class="list-group-item">Fare: ${booking.fare}</li>
        </ul>
    `;
    document.getElementById('output').innerHTML = output;
    })
    .catch((err) => console.log(err))
}

function getCrsCode(station) {
    var crsCode;
    var request = new XMLHttpRequest();
    request.open('GET', `https://transportapi.com/v3/uk/places.json?app_id=afb6eca7&app_key=b1b7b06339f68239a44bfac7c1c0869a&query=${station}&type=train_station`, false);  // `false` makes the request synchronous
    request.send(null);
    
    
    let jsonData = JSON.parse(request.responseText);
    crsCode = jsonData.member[0].station_code;
    console.log(crsCode);
    
    
    
    
    
    // fetch(`https://transportapi.com/v3/uk/places.json?app_id=1d1e976b&app_key=cd9435f76598dee5b5d50bdfab5af968&query=${station}&type=train_station`)
    // .then((res) => res.json())
    // .then((data) => {
    // console.log(data);
    // crsCode = data.member[0].station_code;
    // console.log(crsCode);
    // });

    return crsCode;
}

function getStationName(station) {
    var stationName;
    var request = new XMLHttpRequest();
    request.open('GET', `https://transportapi.com/v3/uk/places.json?app_id=afb6eca7&app_key=b1b7b06339f68239a44bfac7c1c0869a&query=${station}&type=train_station`, false);  // `false` makes the request synchronous
    request.send(null);
    
    let jsonData = JSON.parse(request.responseText);
    stationName = jsonData.member[0].name;
    console.log(stationName);
    
    
    
    // var stationName;
    
    // fetch(`https://transportapi.com/v3/uk/places.json?app_id=1d1e976b&app_key=cd9435f76598dee5b5d50bdfab5af968&query=${station}&type=train_station`)
    // .then((res) => res.json())
    // .then((data) => {
    // console.log(data);
    // stationName = data.member[0].name;
    // console.log(stationName);
    // });

    return stationName;
}

function addToDatabase(newBody) {
    fetch('http://localhost:8080/add/', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(newBody)
    });
    // let data = await resp.json();
    // if(data.result == null) {
    //     console.log('retrieving data');
    //     return addToDatabase(newBody);
    // } else if (data.result == "SUCCESS") {
    //     console.log('success');
    //     return data;
    // }
}

async function getTicketByEmail(email) {
    fetch(`http://localhost:8080/search/email/rdaly1994@gmail.com`)
    // console.log(resp.body);
        .then((response) => response.json())
        .then((data) => {
            console.log(data);
        });
    // fetch(`http://localhost:8080/search/email/${email}`)
    //     .then(res => console.log(res));
    // if(data.result == null) {
    //     console.log('retrieving data');
    //     setTimeout(getTicketByEmail(email), 500);
    // } else if (data.result == "SUCCESS") {
    //     console.log('success');
    //     return data;
    // }
}

function formSubmit(e) {
    e.preventDefault();

    let departureStation = document.getElementById('departureStation').value;
    let destinationStation = document.getElementById('destinationStation').value;
    let date = document.getElementById('date').value;
    let earliestDepartureTime = document.getElementById('earliestDepartureTime').value;
    let latestArrivalTime = document.getElementById('latestArrivalTime').value;
    let bookingEmail = document.getElementById('bookingEmail').value;
    let departureStationCrsCode;
    var destinationStationCrsCode;

    departureStationCrsCode = getCrsCode(departureStation);
    departureStation = getStationName(departureStation);
    destinationStationCrsCode = getCrsCode(destinationStation);
    destinationStation = getStationName(destinationStation);

    console.log(departureStationCrsCode);
    console.log(departureStation);
    console.log(destinationStationCrsCode);
    console.log(destinationStation);

    // fetch(`https://transportapi.com/v3/uk/places.json?app_id=1d1e976b&app_key=cd9435f76598dee5b5d50bdfab5af968&query=${destinationStation}&type=train_station`)
    // .then((res) => res.json())
    // .then((data) => {
    // console.log(data.member[0].station_code);
    // // let jsonData = JSON.parse(data);
    // // console.log(jsonData);
    // destinationStationCrsCode = data.member[0].station_code;
    // console.log(destinationStationCrsCode);
    // destinationStation = data.member[0].name;

    // });

    // console.log(destinationStationCrsCode);

    var request = new XMLHttpRequest();
    request.open('GET', `https://transportapi.com/v3/uk/public/journey/from/crs:${departureStationCrsCode}/to/crs:${destinationStationCrsCode}/by/${date}/${latestArrivalTime}.json?app_id=afb6eca7&app_key=b1b7b06339f68239a44bfac7c1c0869a&modes=train&service=silverrail`, false);  // `false` makes the request synchronous
    request.send(null);
    
    let jsonData = JSON.parse(request.responseText);
    

        
    let numRoutes = jsonData.routes.length;
    let route;
    console.log(destinationStationCrsCode);
    
    for (i = 0; i < numRoutes; i++){
        if (jsonData.routes[i].departure_time >= earliestDepartureTime) {
            route = jsonData.routes[i];
            break;
        }
    }
    
    // post to the database using fetch, the ticket brought -- create another mapping for post in backend

    // output to reservations screen
    let departureTime = route.departure_time;
    let arrivalTime = route.arrival_time;
    let trainID;
    let ticketReferenceNumber = Math.floor(Math.random() * 10000);
    
    for (j = 0; j < route.route_parts.length; j++) {
        if (route.route_parts[j].mode == "train"){
            trainID = route.route_parts[j].line_name;
            break;
        }
    }

    let newBody = {
        arrivalTime: arrivalTime.toString(),
        departureStation:departureStation.toString(),
        departureTime: departureTime.toString(),
        destinationStation: destinationStation.toString(),
        fare: null,
        trainID: trainID.toString(),
        email: bookingEmail.toString(),
        ticketReferenceNumber: ticketReferenceNumber,
    };

    addToDatabase(newBody);
    console.log('done');
    getReservation(newBody);
}



function getReservation(newBody) {

    // let bookingEmail = document.getElementById('bookingEmail').value;
    console.log(newBody);
    newBody = JSON.stringify(newBody);
    console.log(newBody);
    localStorage.setItem("newBody", newBody);
    // getTicketByEmail(bookingEmail).then(data => {
    //     console.log(data);
    window.location.href = "/reservation.html";




    // let reservationOutput = '<h2 class="mb-4">Booking</h2>';
    // fare = 0;
    // reservationOutput = `
    //     <ul class="list-group mb-3">
    //         <li class="list-group-item">Ticket Reference Number: ${newBody.ticketReferenceNumber}</li>
    //         <li class="list-group-item">Train ID: ${newBody.trainID}</li>
    //         <li class="list-group-item">Departure Station: ${newBody.departureStation}</li>
    //         <li class="list-group-item">Departure Time: ${newBody.departureTime}</li>
    //         <li class="list-group-item">Destination Station: ${newBody.destinationStation}</li>
    //         <li class="list-group-item">Arrival Time: ${newBody.arrivalTime}</li>
    //         <li class="list-group-item">Fare: ${fare}</li>
    //     </ul>
    // `;
    // document.getElementById('ticketReferenceNumber').innerHTML = "Ticket Reference Number: " + newBody.ticketReferenceNumber;
    // document.getElementById('trainID').innerHTML = newBody.trainID;
    // document.getElementById('departureStation').innerHTML = newBody.departureStation;
    // document.getElementById('departureTime').innerHTML = newBody.departureTime;
    // document.getElementById('destinationStation').innerHTML = newBody.destinationStation;
    // document.getElementById('arrivalTime').innerHTML = newBody.arrivalTime;
    // document.getElementById('fare').innerHTML = fare;
    

    // window.location.href = "/reservation.html";
}