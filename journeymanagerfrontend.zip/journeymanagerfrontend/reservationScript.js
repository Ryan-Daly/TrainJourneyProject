

function getReservation(e) {
    e.preventDefault();

    let bookingEmail = document.getElementById('bookingEmail').value;

    fetch(`http://localhost:8080/search/email/${bookingEmail}`)
    .then((res) => res.json())
    .then((data) => {
        console.log(data);


        let reservationOutput = '<h2 class="mb-4">Booking</h2>';
        fare = 0;
        reservationOutput = `
            <ul class="list-group mb-3">
                <li class="list-group-item">Booking Reference Number: ${data.bookingReferenceNumber}</li>
                <li class="list-group-item">Ticket Reference Number: ${data.ticketReferenceNumber}</li>
                <li class="list-group-item">Train ID: ${data.trainID}</li>
                <li class="list-group-item">Departure Station: ${data.departureStation}</li>
                <li class="list-group-item">Departure Time: ${data.departureTime}</li>
                <li class="list-group-item">Destination Station: ${data.destinationStation}</li>
                <li class="list-group-item">Arrival Time: ${data.arrivalTime}</li>
                <li class="list-group-item">Fare: ${fare}</li>
            </ul>
        `;
        document.getElementById('reservationOutput').innerHTML = reservationOutput;
    });
    // window.location.href = "/reservation.html";
}